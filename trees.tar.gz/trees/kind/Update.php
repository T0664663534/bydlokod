<!DOCTYPE html>
<html>
<head>
    <meta charset="utf-8">
    <link rel="stylesheet" type="text/css" href="kind.css">
    <title>Kind</title>
</head>
<body>
<hr>
</hr>

<?php

try
{
    $db = new PDO('mysql:host=localhost;dbname=Trees','root','123');
}
catch(PDOException $e) {
    echo $e->getMessage();
}
$kindId = $_GET['id'];
$name = $_POST['name'];
$query = $db->prepare("SELECT * FROM tree_kind WHERE id = ".$kindId);
$query->execute();
$kind = $query->fetch();
if ($name != ''){

    try {
        $query = $db->prepare("UPDATE tree_kind SET name = '$name' WHERE id = ".$kindId);
        $query->execute();
    } catch (PDOException $e) {
        echo $e->getMessage();
    }
    echo "UPDATE 'tree_kind' SET 'name'=  '$name' WHERE id = ".$kindId;
    {
        echo '<b>Запись изменена</b>';
//print_r($result);
    }

}

?>

<form method="post" action="#">
    <p><b>Update Рода дерева</b></p>
    <p>

        Название <input type="text" name="name" value="<?php echo $family['name']; ?>"><br>

    </p>
    <p><input class="a" type="submit"></p>
</form>
<a class="a" href="/kind/add.php">Добавить</a>
<a class="a" href="/kind/index.php">Назад</a>

</body>