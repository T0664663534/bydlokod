<!DOCTYPE html>
<html>
<head>
    <meta charset="utf-8">
    <title>Trees</title>
</head>
<body>
<hr>
</hr>

<?php

try
{
    $db = new PDO('mysql:host=localhost;dbname=Trees','root','123');
}
catch(PDOException $e) {
    echo $e->getMessage();
}
$typeId = $_GET['id'];
$name = $_POST['name'];
$query = $db->prepare("SELECT * FROM tree_type WHERE id = ".$typeId);
$query->execute();
$type = $query->fetch();
if ($name != ''){

    try {
        $query = $db->prepare("UPDATE tree_type SET name = '$name' WHERE id = ".$typeId);
        $query->execute();
    } catch (PDOException $e) {
        echo $e->getMessage();
    }
    echo "UPDATE 'tree_type' SET 'name'=  '$name' WHERE id = ".$typeId;
    {
        echo '<b>Запись изменена</b>';
//print_r($result);
    }

}

?>

<form method="post" action="#">
    <p><b>Update типа дерева</b></p>
    <p>

        Название <input type="text" name="name" value="<?php echo $type['name']; ?>"><br>

    </p>
    <p><input type="submit"></p>
</form>
<a href="/type/add.php">Добавить</a>
<a href="/type/index.php">Назад</a>
<hr>
</hr>
</body>