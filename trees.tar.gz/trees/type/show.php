<!DOCTYPE html>
<html>
<head>
    <meta charset="utf-8">
    <link rel="stylesheet" type="text/css" href="type.css">
    <title>types</title>
</head>
<body>

<table>
    <tr>

        <th>name</th>


    </tr>
    <?php
    /**
     * Created by PhpStorm.
     * User: deneb
     * Date: 19.04.16
     * Time: 20:20
     */
    try {
        $db = new PDO('mysql:host=localhost;dbname=Trees', 'root', '123');
    } catch (PDOException $e) {
        echo $e->getMessage();
    }
    $typeId = intval($_GET['id']);
    $query = $db->prepare("SELECT
		id,
		name
        FROM tree_type");
    $query->execute();
    $type = $query->fetch();
    echo '<tr>
            <td>'.$type['name'].'</td>
            </tr>';
    //print_r($result);
    ?>

</table>
<a class="a" href="/type/add.php">Добавить</a>
<a class="a" href="/type/index.php">Назад</a>
<a class="a" href="/type/Update.php?id=<?php echo $treeId; ?>">Update</a>

</body>